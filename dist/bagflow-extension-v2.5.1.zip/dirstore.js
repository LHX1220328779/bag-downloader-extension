// 保存目录句柄的持久化（IndexedDB）。
// 句柄本身无法放进 chrome.storage，因此存放在扩展源的 IndexedDB 中，
// 弹窗、授权窗口与 offscreen 文档共享同一数据库。
const DirStore = (() => {
  const DB_NAME = 'bagflow-dirs';
  const STORE = 'handles';
  let dbPromise = null;

  function open() {
    if (!dbPromise) {
      dbPromise = new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: 'id' });
        req.onsuccess = () => {
          req.result.onversionchange = () => { req.result.close(); dbPromise = null; };
          resolve(req.result);
        };
        req.onerror = () => { dbPromise = null; reject(req.error); };
      });
    }
    return dbPromise;
  }

  async function run(mode, fn) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode);
      const store = tx.objectStore(STORE);
      const req = fn(store);
      tx.oncomplete = () => resolve(req ? req.result : undefined);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  return {
    // record: { id, name, handle }
    put: (record) => run('readwrite', (s) => s.put(record)),
    get: (id) => run('readonly', (s) => s.get(id)),
    all: () => run('readonly', (s) => s.getAll()),
    remove: (id) => run('readwrite', (s) => s.delete(id)),
    async claim(handle) {
      if (handle?.kind !== 'directory') throw new Error('请选择保存目录');
      return navigator.locks.request('bagflow-directory-registry', async () => {
        for (const rec of await run('readonly', s => s.getAll())) {
          if (rec.handle && await handle.isSameEntry(rec.handle)) return rec;
        }
        const rec = { id: crypto.randomUUID(), name: handle.name, handle, addedAt: Date.now() };
        await run('readwrite', s => s.put(rec)); return rec;
      });
    },
    // 权限检查（无需用户手势）
    async permission(record) {
      if (!record || !record.handle) return 'missing';
      return record.handle.queryPermission({ mode: 'readwrite' });
    },
  };
})();
