// 在 MAIN world 只读 /table、/search 当前网页的 Vue 表单。
(() => {
  if (window.__bagToolMain) return;
  window.__bagToolMain = true;
  let last = '', lastSentAt = 0, lastPage = '';
  function findForm(vm, path, depth = 0) {
    if (!vm || vm._inactive || vm._isDestroyed || depth > 40) return null;
    if (vm.$el?.getClientRects && vm.$el.getClientRects().length === 0) return null;
    const f = vm.form;
    const api = path === '/search' ? '/api/bag/search' : '/api/break/search';
    if ((!vm.regeditForm?.url || vm.regeditForm.url === api) && f &&
      ('mine' in f || 'mine_code' in f) && ('type' in f || 'bag_type' in f) && ('truck_no' in f || 'name' in f)) return f;
    for (const child of vm.$children || []) { const found = findForm(child, path, depth + 1); if (found) return found; }
    return null;
  }
  function tick(force = false) {
    if (document.visibilityState !== 'visible') return;
    try {
      if (lastPage !== location.href) { lastPage = location.href; last = ''; force = true; }
      const path = new URL(location.href).pathname.replace(/\/+$/, '');
      if (!['/table', '/search'].includes(path)) return;
      const form = findForm(document.querySelector('#app')?.__vue__, path);
      if (!form) return; // 切到 MDC/其他路由时保留上次条件。
      const payload = {
        truck_no: form.truck_no ?? form.name ?? '', mine_code: form.mine_code ?? form.mine ?? '',
        bag_type: form.bag_type ?? form.type ?? '', break_source: form.break_source ?? '',
        hasSource: 'break_source' in form, page: location.href,
      };
      const key = JSON.stringify(payload);
      if (!force && key === last && Date.now() - lastSentAt < 10000) return;
      last = key; lastSentAt = Date.now();
      window.postMessage({ __bagTool: 'form', payload }, location.origin);
    } catch (_) { /* 页面切换时下轮重新读取 */ }
  }
  setInterval(tick, 500);
  document.addEventListener('visibilitychange', () => tick(true));
  window.addEventListener('focus', () => tick(true));
  window.addEventListener('pageshow', () => tick(true));
  window.addEventListener('popstate', () => tick(true));
  window.addEventListener('hashchange', () => tick(true));
  window.addEventListener('message', (event) => {
    if (event.source === window && event.origin === location.origin && event.data?.__bagTool === 'capture-request') tick(true);
  });
  for (const method of ['pushState', 'replaceState']) if (window.history?.[method]) {
    const original = window.history[method];
    window.history[method] = function (...args) { const result = original.apply(this, args); tick(true); return result; };
  }
  tick(true);
})();
