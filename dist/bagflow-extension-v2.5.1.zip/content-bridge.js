// 页面只允许提交筛选值，不能触发回传、下载或删除。
window.addEventListener('message', (event) => {
  if (event.source !== window || event.origin !== location.origin || event.data?.__bagTool !== 'form') return;
  const payload = event.data.payload;
  if (!payload || typeof payload !== 'object') return;
  // MAIN world 已控制频率；强制刷新不能被旧值去重挡住。
  chrome.runtime.sendMessage({ type: 'capture', payload }).catch(() => {});
});
const requestCapture = () => window.postMessage({ __bagTool: 'capture-request' }, location.origin);
document.addEventListener('visibilitychange', requestCapture);
window.addEventListener('focus', requestCapture);
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'capture:request') requestCapture();
});
requestCapture();
