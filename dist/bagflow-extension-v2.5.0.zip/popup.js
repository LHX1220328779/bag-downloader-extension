const $ = (s) => document.querySelector(s);
const LIVE = ['fetching', 'running', 'waiting_vehicle'];
const STATUS = { ready: ['待执行', 'idle'], fetching: ['查询中', 'run'], running: ['执行中', 'run'],
  waiting_vehicle: ['离线告警', 'err'], stopped: ['已停止', 'warn'], done: ['已完成', 'ok'], error: ['需处理', 'err'] };
const BAG_STATE = { pending: '待处理', downloading: '下载中', done: '完成', failed: '失败',
  submitting: '正在提交', submitted: '回传中', confirming: '等待入库', uncertain: '提交待确认', server_failed: '服务器回传异常' };
let tasks = [], dirs = [], lastDirId, captured, lookups = { mines: {}, types: {}, sources: [], reasons: [] };
let loading = false, loadAgain = false;
let taskExpansion = {}, operationsInitialized = false;
let setupExpanded = true;
let directoryLabels = {}, directorySelections = {}, directoryHistory = [], directoryKey = null, selectedDirectoryId = '';
let creating = false, selectingDirectory = false;
let directoryMeasurement = {};
const pendingConfirm = new Map();
const handles = new Map();
const dirPermissions = new Map(), authorizing = new Set();
const bagPages = new Map();
const taskRenderKeys = new Map();
const send = async (msg) => { try { return await chrome.runtime.sendMessage(msg) || { ok: false, error: '后台无响应' }; }
  catch (e) { return { ok: false, error: e.message }; } };
const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
const keyed = (e, key) => { e.dataset.nodeKey = key; return e; };
const clock = (ts) => new Date(ts).toLocaleTimeString('zh-CN', { hour12: false });
const toInput = (d) => BagCore.localTime(d).replace(' ', 'T');
const bytesText = (n) => `${((n || 0) / 1048576).toFixed(1)} MB`;
function toast(text) { $('#toast').textContent = text; $('#toast').classList.add('show'); clearTimeout(toast.timer); toast.timer = setTimeout(() => $('#toast').classList.remove('show'), 4000); }
function formMsg(text, tone = '') { $('#formMsg').textContent = text; $('#formMsg').className = 'formmsg ' + tone; }
function preset(kind) {
  const end = new Date(), start = new Date();
  if (kind === 'yesterday') { end.setDate(end.getDate()-1); start.setDate(start.getDate()-1); }
  if (kind === 'week') start.setDate(start.getDate()-6);
  start.setHours(0,0,0,0); end.setHours(23,59,59,0); PanelUI.setDate('start', toInput(start)); PanelUI.setDate('end', toInput(end));
  document.querySelectorAll('[data-preset]').forEach((b) => {
    const selected = b.dataset.preset === kind;
    b.classList.toggle('selected', selected); b.setAttribute('aria-pressed', String(selected));
  });
}
function filterValues() {
  const c = captured || {};
  return { truck_no: c.truck_no || '', mine_code: c.mine_code || '', bag_type: c.bag_type || '', break_source: c.break_source || '' };
}
function renderCaptured() {
  const f = filterValues();
  $('#capTruck').textContent = f.truck_no || '未选择';
  $('#capMine').textContent = lookups.mines[f.mine_code] || f.mine_code || '未选择';
  $('#capType').textContent = f.bag_type || '未选择';
  $('#capSource').textContent = lookups.sources.find((s) => s.value === f.break_source)?.name || f.break_source || '不限';
  for (const [id, value] of [['chipTruck', f.truck_no], ['chipMine', f.mine_code], ['chipType', f.bag_type], ['chipSource', f.break_source]]) $('#' + id).classList.toggle('on', !!value);
  $('#capTime').textContent = captured?.capturedAt ? `捕获于 ${clock(captured.capturedAt)}` : '';
  $('#setupPreview').textContent = [f.truck_no, f.bag_type].filter(Boolean).join(' · ');
}
function selectedOperations() { return { transfer: $('#modeTransfer').checked, download: $('#modeDownload').checked }; }
function resizeDirectoryInput() {
  const input = $('#taskDirectory');
  const width = input.offsetWidth;
  if (!width || (directoryMeasurement.width === width && directoryMeasurement.value === input.value)) return;
  directoryMeasurement = { width, value: input.value };
  input.style.height = 'auto'; input.style.height = Math.max(49, input.scrollHeight + 2) + 'px';
}
function directoryInputError() {
  try {
    const path = DirPaths.normalize($('#taskDirectory').value), dir = dirs.find(d => d.id === selectedDirectoryId);
    if (path && dir) {
      const windows = /^[a-z]:\\|^\\\\/i.test(path), leaf = DirPaths.leaf(path);
      if (windows ? leaf.toLowerCase() !== dir.name.toLowerCase() : leaf !== dir.name) return `路径应以所选目录「${dir.name}」结尾；实际保存位置由所选目录决定`;
    }
    return '';
  } catch (e) { return e.message; }
}
function rememberDirectoryInput() {
  if (!selectedDirectoryId) return;
  const path = $('#taskDirectory').value;
  directoryLabels[selectedDirectoryId] = path;
  send({ type: 'directory:label-draft', dirId: selectedDirectoryId, path }).then(r => { if (!r.ok) toast(r.error); });
}
function directoryOptions() {
  return TaskDirectories.handleChoices(filterValues(), dirs, directoryHistory, tasks).filter(d => handles.has(d.id));
}
function setSelectedDirectory(id) {
  selectedDirectoryId = id;
  const dir = dirs.find(d => d.id === id);
  $('#taskDirectory').value = Object.hasOwn(directoryLabels, id) ? directoryLabels[id] : dir?.displayPath || dir?.path || '';
}
async function useDirectory(rec) {
  const filters = filterValues(), key = TaskDirectories.filterKey(filters);
  const r = await send({ type: 'directory:select', dirId: rec.id }); if (!r.ok) throw Error(r.error);
  dirs = [r.directory, ...dirs.filter(d => d.id !== rec.id)]; handles.set(rec.id, rec); dirPermissions.set(rec.id, 'granted');
  directorySelections[key] = rec.id;
  const remembered = await send({ type: 'directory:selection', filters, dirId: rec.id }); if (!remembered.ok) throw Error(remembered.error);
  if (key === TaskDirectories.filterKey(filterValues())) { directoryKey = key; setSelectedDirectory(rec.id); }
  renderTaskDirectory(); renderCreateState();
  // 再次选择同一目录也恢复原任务，不替换它们的目录句柄、进度或运行代次。
  const authorized = await send({ type: 'directory:authorized', dirId: rec.id }); if (!authorized.ok) throw Error(authorized.error);
}
function renderTaskDirectory() {
  const filters = filterValues(), key = TaskDirectories.filterKey(filters);
  if (key !== directoryKey) {
    if ($('#directoryHistory').matches(':popover-open')) $('#directoryHistory').hidePopover();
    directoryKey = key;
    const preferred = directorySelections[key] || directoryOptions().find(d => d.matching)?.id || '';
    setSelectedDirectory(dirs.some(d => d.id === preferred && d.backend !== 'browser') ? preferred : '');
  }
  const dir = dirs.find(d => d.id === selectedDirectoryId), granted = dir && dirPermissions.get(dir.id) === 'granted';
  const path = !directoryInputError() ? DirPaths.normalize($('#taskDirectory').value) : '';
  $('#directorySelected').textContent = dir ? path || dir.name : '尚未选择保存目录';
  $('#dirPick').textContent = selectingDirectory ? '正在选择…' : dir ? '更换保存目录' : '选择保存目录';
  $('#dirPick').disabled = selectingDirectory || creating;
  $('#directoryAccess').hidden = !dir;
  $('#directoryAccessText').textContent = granted ? '已允许写入' : handles.has(dir?.id) ? '需要允许写入此目录' : '目录不可用，请重新选择';
  $('#dirAuthorize').hidden = !dir || granted || !handles.has(dir.id);
  $('#dirAuthorize').disabled = authorizing.has(dir?.id);
  $('#directoryPathDetails').hidden = !dir;
  $('#directoryHistoryButton').disabled = creating || selectingDirectory || !directoryOptions().length;
  resizeDirectoryInput();
}
function renderCreateState() {
  const f = filterValues(), o = selectedOperations();
  const error = o.download ? directoryInputError() : '';
  $('#directoryError').textContent = error; $('#directoryError').hidden = !error;
  $('#taskDirectory').setAttribute('aria-invalid', String(!!error));
  $('#createBtn').disabled = creating || selectingDirectory || !!error || (o.download && (!selectedDirectoryId || dirPermissions.get(selectedDirectoryId) !== 'granted')) || !f.truck_no || !f.mine_code || !f.bag_type || (!o.transfer && !o.download) || (o.transfer && !$('#reason').value);
}
function renderModeSelection() {
  $('#transferOptions').hidden = !$('#modeTransfer').checked;
  $('#directorySection').hidden = !$('#modeDownload').checked;
  if (!$('#modeDownload').checked && $('#directoryHistory').matches(':popover-open')) $('#directoryHistory').hidePopover();
  if (!$('#modeTransfer').checked && $('#reasonPopover').matches(':popover-open')) $('#reasonPopover').hidePopover();
  renderCreateState();
}
function taskDirectoryPath(t) {
  let path = t.dirPath;
  if (!path) {
    const item = [...t.items].reverse().find(i => i.downloadPath);
    if (item) path = DirPaths.splitFile(item.downloadPath).directory;
    else {
      const dir = t.downloadBackend === 'browser' || t.directorySnapshot ? null : dirs.find(d => d.id === t.dirId);
      path = dir?.displayPath || dir?.path || '';
    }
  }
  try { return path ? DirPaths.normalize(path) : ''; } catch (_) { return ''; }
}
function authorize(id) {
  const rec = handles.get(id);
  if (authorizing.has(id)) return;
  if (!rec?.handle) { toast('原任务目录不可用，无法恢复目录写入权限'); return; }
  // 句柄提前缓存，requestPermission 保持直接用户手势。
  let request;
  try { request = rec.handle.requestPermission({ mode: 'readwrite' }); } catch (e) { toast(e.message); return; }
  authorizing.add(id); renderTasks();
  request.then(async (perm) => {
    if (perm !== 'granted') return toast('未获得写入权限');
    const r = await send({ type: 'directory:authorized', dirId: id });
    if (!r.ok) throw new Error(r.error);
    await chrome.storage.local.set({ lastAuthAt: Date.now() });
    toast(`已授权 ${rec.name}，任务将自动继续`);
  }).catch((e) => toast(e.message)).finally(async () => { authorizing.delete(id); await load(); });
}
function progressCard(t, transfer) {
  const items = [...(transfer ? t.transfers || [] : t.items || [])].sort(BagCore.sort);
  const done = items.filter((i) => i.state === 'done').length, failed = items.filter((i) => ['failed', 'server_failed'].includes(i.state)).length;
  const card = keyed(h('section', 'phase-card'), transfer ? 'transfer-phase' : 'download-phase');
  const title = keyed(h('div', 'phase-title'), 'title'); title.append(h('strong', '', transfer ? '↑ 回传进度' : '↓ 下载进度'), h('span', 'muted', `${done} / ${items.length}`)); card.append(title);
  const progress = keyed(h('div', 'progress'), 'progress'), bar = h('div', 'bar'); bar.style.width = `${items.length ? done/items.length*100 : 0}%`; progress.append(bar); card.append(progress);
  if (failed) card.append(keyed(h('p', 'error-text', transfer ? `${failed} 个服务器异常，持续核查` : `${failed} 个下载失败`), 'error'));
  const note = transfer ? t.discoveryError || t.transferError || t.transferMessage : t.searchError || t.message;
  if (note) card.append(keyed(h('p', 'phase-note', note), 'note'));
  const phase = transfer ? 'transfer' : 'download', key = `${t.id}:${phase}`, pageSize = 80;
  const currentIndex = items.findIndex((i) => !['done', 'failed'].includes(i.state));
  const lastPage = Math.max(0, Math.ceil(items.length / pageSize) - 1);
  const page = Math.min(lastPage, bagPages.has(key) ? bagPages.get(key) : Math.floor(Math.max(0, currentIndex) / pageSize));
  const list = keyed(h('ul', 'bags'), 'list'); list.dataset.list = key; list.dataset.page = String(page);
  for (const i of items.slice(page * pageSize, (page + 1) * pageSize)) {
    const li = keyed(h('li', `bag s-${i.state}`), i.dirpath || i.key || BagCore.fileKey(i)), name = h('div', 'bag-name', BagCore.shortFilename(i.filename));
    let status = BAG_STATE[i.state] || i.state;
    if (i.skipped) status = '本地文件已验证';
    if (transfer && ['submitted', 'confirming'].includes(i.state)) status += ` · ${i.percentage || 0}%`;
    if (!transfer && i.needsValidation && i.jobId) status = '核验完整文件';
    else if (!transfer && i.state === 'downloading') status += ` · ${bytesText(i.bytes)}${i.totalBytes ? ' / ' + bytesText(i.totalBytes) : ''}`;
    li.append(name, h('div', 'bag-detail', `${status} · ${BagCore.recordingTime(i)}`));
    if (i.error) li.append(keyed(h('div', 'error-text', i.error), 'error'));
    li.title = `${i.filename}\n${status}\n${i.error || ''}`; list.append(li);
  }
  card.append(list);
  if (items.length > pageSize) {
    const pager = keyed(h('div', 'bag-pager'), 'pager');
    pager.append(h('span', 'muted', `第 ${page + 1} / ${lastPage + 1} 页`));
    for (const [label, target, disabled] of [['上一页', page - 1, page === 0], ['下一页', page + 1, page === lastPage], ['跟随当前', 'auto', !bagPages.has(key)]]) {
      const button = h('button', 'link-btn', label); button.dataset.act = 'bag-page'; button.dataset.phase = phase; button.dataset.page = String(target); button.disabled = disabled; pager.append(button);
    }
    card.append(pager);
  }
  return card;
}
function taskCard(t, sharedDownloadRoot = '') {
  t = BagCore.normalizeTask(t);
  t = { ...t, items: t.items.filter(i => !i.coverageExcluded), transfers: t.transfers.filter(i => !i.coverageExcluded) };
  const live = LIVE.includes(t.status), transfer = BagCore.wantsTransfer(t), download = BagCore.wantsDownload(t);
  const card = h('article', `task${(t.alert || t.coverageAlert) && live ? ' task-alert' : ''}`); card.dataset.id = t.id;
  const permission = dirPermissions.get(t.dirId), needsAuth = download && t.downloadBackend !== 'browser' && ((permission && permission !== 'granted') || t.directoryBlocked);
  let [label,tone] = STATUS[t.status] || ['未知','idle'];
  if (live && needsAuth) { label = '下载待授权'; tone = 'warn'; }
  if (live && t.coverageAlert) { label = '覆盖告警'; tone = 'warn'; }
  if (live && t.locationBlocked && !t.coverageAlert && !needsAuth && !t.alert) { label = t.locationWait ? '等待目录' : '目录不匹配'; tone = t.locationWait ? 'idle' : 'warn'; }
  if (t.status === 'done' && [...t.items, ...(t.transfers || [])].some((i) => ['failed', 'server_failed'].includes(i.state))) { label = '完成（有失败）'; tone = 'warn'; }
  if (live && t.localVerificationOnly && !needsAuth) label = '核验文件';
  const fold = keyed(h('details', 'task-fold'), 'fold'); fold.dataset.taskFold = t.id; fold.open = !!taskExpansion[t.id];
  const top = h('summary', 'task-top'), info = h('div'), heading = h('div', 'task-heading');
  heading.append(h('h3', '', t.name), h('span', `pill ${tone}`, label));
  const range = h('p', 'task-range'); range.append(h('span', '', t.start), h('span', 'range-separator', '→'), h('span', '', t.end));
  info.append(heading, h('p', 'meta', `${transfer ? (download ? '回传 + 下载' : '仅回传') : '仅下载'} · ${t.mineName || t.filters.mine_code} · 来源：${t.filters.break_source || '不限'}`), range);
  const savedPath = taskDirectoryPath(t);
  if (download && (savedPath || t.dirName)) info.append(keyed(h('p', 'task-save-path', savedPath || t.dirName), 'save-path'));
  const progress = [transfer ? `回传 ${(t.transfers || []).filter((i) => i.state === 'done').length}/${(t.transfers || []).length}` : '', download ? `下载 ${t.items.filter((i) => i.state === 'done').length}/${t.items.length}` : ''].filter(Boolean).join(' · ');
  info.append(h('p', 'compact-progress', progress));
  top.append(info);
  const body = h('div', 'task-body');
  if (t.alert && live) body.append(keyed(h('div', 'alert-box', t.alert), 'vehicle-alert'));
  if (transfer && t.vehicleCheckedAt) body.append(keyed(h('p', 'meta', `${t.vehicleMessage} · ${clock(t.vehicleCheckedAt)}`), 'vehicle'));
  if (t.queryAt) body.append(keyed(h('p', 'meta', `文件查询 ${clock(t.queryAt)}`), 'query'));
  if (transfer) body.append(progressCard(t, true));
  if (download) body.append(progressCard(t, false));
  fold.append(top, body); card.append(fold);
  if (t.coverageAlert) card.append(keyed(h('div', 'alert-box coverage-alert', t.coverageAlert), 'coverage-alert'));
  if (live && t.locationWait) {
    const waiting = keyed(h('div', 'task-location-wait'), 'location-wait'); waiting.setAttribute('role', 'status');
    waiting.append(h('span', '', '浏览器下载目录尚未包含本任务保存位置'));
    if (t.locationWait.current) waiting.append(h('span', 'muted', `当前下载目录：${t.locationWait.current}`));
    waiting.append(h('span', '', `请将浏览器下载位置设为：${sharedDownloadRoot || t.locationWait.required}`));
    card.append(waiting);
  } else if (live && t.locationBlocked) card.append(keyed(h('div', 'alert-box coverage-alert', t.message), 'location-alert'));
  if (needsAuth) {
    const authPanel = keyed(h('div', 'task-auth'), 'auth'); authPanel.setAttribute('role', 'status');
    authPanel.append(h('strong', '', '保存目录需要授权'), h('p', '', '浏览器需要重新允许写入此任务的目录。任务与已完成进度已保留，授权后自动继续。'));
    const auth = h('button', 'ghost-btn', authorizing.has(t.dirId) ? '正在授权…' : '授权本任务目录');
    auth.dataset.act = 'auth-dir'; auth.disabled = authorizing.has(t.dirId); authPanel.append(auth); card.append(authPanel);
  }
  const actions = keyed(h('div', 'actions'), 'actions');
  for (const [act,text,cls,disabled] of [['execute','执行','primary-sm',live || t.status === 'done'],['stop','停止','stop',!live],['delete','删除','text',false]]) {
    const button = h('button', `btn ${cls}`, text); button.dataset.act = act; button.disabled = disabled || pendingConfirm.has(t.id); actions.append(button);
  }
  card.append(actions);
  const confirmation = pendingConfirm.get(t.id);
  if (confirmation) {
    const panel = keyed(h('div', 'task-confirm'), 'confirm'); panel.setAttribute('role', 'alertdialog'); panel.setAttribute('aria-labelledby', `confirm-${t.id}`);
    const title = h('strong', '', confirmation.act === 'stop' ? '停止此任务？' : confirmation.act === 'delete' ? '删除此任务？' : '重试未确认的回传？'); title.id = `confirm-${t.id}`;
    const description = confirmation.act === 'stop' ? '暂停本地调度和下载。已提交的服务器回传可能继续。' : confirmation.act === 'delete' ? '删除本地任务记录，保留已下载文件。' : '请先在网站核实没有正在执行的回传，重试可能重复提交。';
    panel.append(title, h('p', 'confirm-target', t.name), h('p', 'confirm-description', description));
    const buttons = h('div', 'confirm-actions');
    for (const [act, text, cls] of [['confirm-cancel', '取消', ''], ['confirm-apply', confirmation.act === 'stop' ? '确认停止' : confirmation.act === 'delete' ? '确认删除' : '确认重试', 'danger']]) {
      const button = h('button', `btn ${cls}`, text); button.dataset.act = act; buttons.append(button);
    }
    panel.append(buttons); card.append(panel);
  }
  const more = keyed(h('details', 'task-more'), 'more'); more.dataset.key = t.id + ':more'; more.append(h('summary', '', '日志与恢复'));
  if ((t.transfers || []).some((i) => ['uncertain','submitting','server_failed'].includes(i.state))) {
    const retry = h('button', 'link-btn', '重试未确认的回传'); retry.dataset.act = 'retry-uncertain'; retry.disabled = live; more.append(retry);
  }
  const logs = h('ul', 'event-log');
  for (const e of [...(t.events || [])].reverse()) logs.append(h('li', '', `${clock(e.at)} ${e.message}${e.coverageCorrected ? '（已纠正：该包不在任务时间范围）' : ''}`));
  more.append(logs); body.append(more); return card;
}
function renderTasks() {
  const sharedDownloadRoot = DirPaths.commonAncestor(tasks.filter(task => (LIVE.includes(task.status) || task.status === 'ready') && BagCore.wantsDownload(task) && task.downloadBackend === 'browser').map(task => task.dirPath));
  const focused = document.activeElement, focusedTask = focused?.closest('.task')?.dataset.id, focusedAction = focused?.dataset.act;
  for (const [id, confirmation] of pendingConfirm) {
    const task = tasks.find((t) => t.id === id);
    if (!task || task.runToken !== confirmation.token || (confirmation.act === 'stop' && !LIVE.includes(task.status))) pendingConfirm.delete(id);
  }
  const box = $('#tasks'), existing = new Map([...box.children].map((card) => [card.dataset.id, card]));
  const nodes = [...tasks].sort((a,b) => b.createdAt-a.createdAt).map((t) => {
    t = BagCore.normalizeTask(t);
    const key = JSON.stringify([t, dirPermissions.get(t.dirId), authorizing.has(t.dirId),
      !!taskExpansion[t.id], taskDirectoryPath(t), t.locationWait ? sharedDownloadRoot : '', pendingConfirm.get(t.id), bagPages.get(t.id + ':transfer'), bagPages.get(t.id + ':download')]);
    let card = existing.get(t.id);
    if (!card || taskRenderKeys.get(t.id) !== key) {
      const next = taskCard(t, sharedDownloadRoot);
      const pages = new Map([...card?.querySelectorAll('.bags') || []].map((list) => [list.dataset.list, list.dataset.page]));
      card = card ? PanelDOM.patch(card, next) : next;
      for (const list of card.querySelectorAll('.bags')) if (pages.has(list.dataset.list) && pages.get(list.dataset.list) !== list.dataset.page) list.scrollTop = 0;
      taskRenderKeys.set(t.id, key);
    }
    return card;
  });
  PanelDOM.order(box, nodes);
  const ids = new Set(tasks.map((t) => t.id));
  for (const id of taskRenderKeys.keys()) if (!ids.has(id)) taskRenderKeys.delete(id);
  $('#taskCount').textContent = `${tasks.length} 个`; $('#empty').hidden = tasks.length > 0;
  const alarms = tasks.filter((t) => LIVE.includes(t.status) && (t.alert || t.coverageAlert));
  $('#alertSummary').hidden = !alarms.length;
  $('#alertSummary').textContent = [alarms.some(t => t.alert) ? `${alarms.filter(t => t.alert).length} 个任务等待车辆在线` : '', alarms.some(t => t.coverageAlert) ? `${alarms.filter(t => t.coverageAlert).length} 个任务需要核查数据覆盖` : ''].filter(Boolean).join(' · ');
  if (focusedTask && focusedAction) {
    const target = box.querySelector(`[data-id="${focusedTask}"] [data-act="${focusedAction}"]`);
    if (target && target !== document.activeElement) target.focus({ preventScroll: true });
  }
}
async function load() {
  if (loading) { loadAgain = true; return; } loading = true;
  try {
    const st = await chrome.storage.local.get(['tasks','captured','dirs','lastDirId','taskExpansion','setupExpanded','taskOperations','taskDirectoryLabels','taskDirectorySelections','taskDirectoryHistory']);
    tasks = st.tasks || []; dirs = st.dirs || []; lastDirId = st.lastDirId;
    // 正在输入的值由当前侧栏持有，进度刷新不改写它或移动光标。
    directoryLabels = { ...(st.taskDirectoryLabels || {}), ...directoryLabels }; directorySelections = { ...(st.taskDirectorySelections || {}), ...directorySelections }; directoryHistory = st.taskDirectoryHistory || [];
    taskExpansion = st.taskExpansion || {};
    setupExpanded = st.setupExpanded !== false; $('#taskSetup').open = setupExpanded;
    if (!operationsInitialized) { $('#modeTransfer').checked = st.taskOperations?.transfer !== false; $('#modeDownload').checked = st.taskOperations?.download !== false; operationsInitialized = true; }
    renderModeSelection();
    await Promise.all([...new Set([...dirs.map((d) => d.id), ...tasks.map((t) => t.dirId)])].filter(Boolean).map(async (id) => {
      if (dirs.some((d) => d.id === id && d.backend === 'browser')) { dirPermissions.set(id, 'granted'); return; }
      const rec = await DirStore.get(id).catch(() => null);
      if (rec) handles.set(id, rec); else handles.delete(id);
      dirPermissions.set(id, await DirStore.permission(rec).catch(() => 'missing'));
    }));
    captured = st.captured || null;
    renderCaptured(); renderTaskDirectory();
    renderCreateState(); renderTasks();
  } finally { loading = false; if (loadAgain) { loadAgain = false; load(); } }
}
async function loadLookups() {
  const r = await send({ type: 'lookups' });
  if (!r.ok) { toast(`选项加载失败：${r.error}`); return; }
  lookups = r.data;
  renderCaptured();
  PanelUI.renderReasons(lookups.reasons);
}
async function create() {
  if (creating) return;
  const operations = selectedOperations();
  const start = BagCore.inputTime($('#start').value), end = BagCore.inputTime($('#end').value);
  if (!start || !end || start > end) return formMsg('请选择有效时间范围', 'err');
  if (!operations.transfer && !operations.download) return formMsg('请选择回传或下载', 'err');
  if (operations.transfer && !$('#reason').value) return formMsg('请选择回传原因', 'err');
  if (operations.download && directoryInputError()) return formMsg(directoryInputError(), 'err');
  if (operations.download && (!selectedDirectoryId || dirPermissions.get(selectedDirectoryId) !== 'granted')) return formMsg('请先选择保存目录并允许写入', 'err');
  const filters = filterValues();
  const payload = { ...filters, operations, start, end, directory_mode: 'selected', dir_id: operations.download ? selectedDirectoryId : '', download_path: operations.download ? $('#taskDirectory').value : '',
    reason: $('#reason').value, bug_id: $('#bugId').value, remarks: $('#remarks').value };
  creating = true; renderTaskDirectory(); renderCreateState();
  try {
    const r = await send({ type: 'create', payload });
    formMsg(r.ok ? '已创建任务，点击执行开始' : r.error, r.ok ? 'ok' : 'err');
    if (r.ok) {
      toast('任务已创建，点击执行开始'); await chrome.storage.local.set({ setupExpanded: false });
    }
    await load();
  } finally { creating = false; renderTaskDirectory(); renderCreateState(); }
}
$('#createBtn').addEventListener('click', create);
$('#dirPick').addEventListener('click', () => {
  if (selectingDirectory) return;
  if (!window.showDirectoryPicker) return toast('此浏览器不支持目录选择，请使用新版 Chrome 或 Edge');
  let picker;
  try { picker = window.showDirectoryPicker({ id: 'bagflow-save', mode: 'readwrite', ...(handles.get(selectedDirectoryId)?.handle ? { startIn: handles.get(selectedDirectoryId).handle } : {}) }); }
  catch (e) { return toast(e.message); }
  selectingDirectory = true; renderTaskDirectory(); renderCreateState();
  picker.then(async handle => useDirectory(await DirStore.claim(handle))).catch(e => { if (e.name !== 'AbortError') toast(e.message); })
    .finally(async () => { selectingDirectory = false; await load(); });
});
$('#dirAuthorize').addEventListener('click', () => authorize(selectedDirectoryId));
for (const id of ['modeTransfer', 'modeDownload']) $('#' + id).addEventListener('change', () => { renderModeSelection(); chrome.storage.local.set({ taskOperations: selectedOperations() }); });
$('#taskDirectory').addEventListener('input', () => { rememberDirectoryInput(); renderTaskDirectory(); renderCreateState(); });
$('#taskDirectory').addEventListener('keydown', ev => { if (ev.key === 'Enter') ev.preventDefault(); });
$('#directoryHistoryButton').addEventListener('click', () => {
  const popover = $('#directoryHistory');
  if (popover.matches(':popover-open')) { popover.hidePopover(); return; }
  const box = $('#directoryChoices'); box.replaceChildren();
  for (const entry of directoryOptions()) {
    const button = h('button', 'directory-choice'); button.type = 'button'; button.dataset.dirId = entry.id;
    button.setAttribute('aria-pressed', String(entry.id === selectedDirectoryId));
    button.append(h('span', '', entry.displayPath || entry.path || entry.name));
    const used = entry.usedAt ? new Date(entry.usedAt).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }) : '';
    button.append(h('small', '', [entry.truck_no, used, dirPermissions.get(entry.id) === 'granted' ? '已允许写入' : '需授权'].filter(Boolean).join(' · ')));
    button.addEventListener('click', () => {
      const rec = handles.get(entry.id); if (!rec?.handle) return toast('目录不可用，请重新选择');
      let permission;
      try { permission = dirPermissions.get(entry.id) === 'granted' ? Promise.resolve('granted') : rec.handle.requestPermission({ mode: 'readwrite' }); }
      catch (e) { return toast(e.message); }
      selectingDirectory = true; renderTaskDirectory(); renderCreateState(); popover.hidePopover();
      permission.then(perm => { if (perm !== 'granted') throw Error('未获得目录写入权限'); return useDirectory(rec); })
        .catch(e => toast(e.message)).finally(async () => { selectingDirectory = false; await load(); $('#directoryHistoryButton').focus({ preventScroll: true }); });
    }); box.append(button);
  }
  popover.showPopover();
  const anchor = $('.directory-destination').getBoundingClientRect(), width = Math.min(440, innerWidth - 24);
  popover.style.width = width + 'px'; popover.style.maxHeight = Math.min(320, innerHeight - 24) + 'px';
  popover.style.left = Math.max(12, Math.min(anchor.left, innerWidth - width - 12)) + 'px';
  const height = popover.getBoundingClientRect().height;
  popover.style.top = (anchor.bottom + height + 7 <= innerHeight - 12 ? anchor.bottom + 7 : Math.max(12, anchor.top - height - 7)) + 'px';
  (box.querySelector('[aria-pressed="true"]') || box.firstElementChild)?.focus({ preventScroll: true });
});
$('#directoryHistory').addEventListener('toggle', ev => $('#directoryHistoryButton').setAttribute('aria-expanded', String(ev.newState === 'open')));
$('#directoryChoices').addEventListener('keydown', ev => {
  if (!['ArrowDown','ArrowUp','Home','End'].includes(ev.key)) return;
  const buttons = [...ev.currentTarget.children], index = buttons.indexOf(document.activeElement);
  ev.preventDefault(); buttons[ev.key === 'Home' ? 0 : ev.key === 'End' ? buttons.length - 1 : (index + (ev.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length]?.focus();
});
let directoryWidth = 0;
new ResizeObserver(([entry]) => { if (entry.contentRect.width !== directoryWidth) { directoryWidth = entry.contentRect.width; resizeDirectoryInput(); } }).observe($('#taskDirectory'));
$('#reason').addEventListener('change', renderCreateState);
$('#tasks').addEventListener('toggle', (ev) => {
  const id = ev.target.dataset.taskFold;
  if (!id || !ev.target.isConnected || !!taskExpansion[id] === ev.target.open) return;
  taskExpansion[id] = ev.target.open;
  chrome.storage.local.set({ taskExpansion });
}, true);
document.querySelectorAll('[data-preset]').forEach((b) => b.addEventListener('click', () => preset(b.dataset.preset)));
$('#taskSetup').addEventListener('toggle', () => {
  if ($('#taskSetup').open === setupExpanded) return;
  setupExpanded = $('#taskSetup').open; chrome.storage.local.set({ setupExpanded });
});
$('#tasks').addEventListener('click', async (ev) => {
  const btn = ev.target.closest('button[data-act]'); if (!btn) return;
  const id = btn.closest('.task').dataset.id, t = tasks.find((t) => t.id === id), act = btn.dataset.act;
  if (act === 'bag-page') {
    const key = `${id}:${btn.dataset.phase}`;
    if (btn.dataset.page === 'auto') bagPages.delete(key); else bagPages.set(key, Number(btn.dataset.page));
    renderTasks(); return;
  }
  if (act === 'auth-dir') { authorize(t.dirId); return; }
  if (['stop', 'delete', 'retry-uncertain'].includes(act)) {
    pendingConfirm.set(id, { act, token: t.runToken }); renderTasks();
    $('#tasks').querySelector(`[data-id="${id}"] [data-act="confirm-cancel"]`)?.focus({ preventScroll: true }); return;
  }
  if (act === 'confirm-cancel') { pendingConfirm.delete(id); renderTasks(); return; }
  let action = act, expectedRunToken;
  if (act === 'confirm-apply') {
    const confirmation = pendingConfirm.get(id);
    if (!confirmation || confirmation.token !== t.runToken) { pendingConfirm.delete(id); renderTasks(); return; }
    action = confirmation.act; expectedRunToken = confirmation.token; pendingConfirm.delete(id);
  }
  btn.disabled = true;
  const r = await send({ type: action, id, expectedRunToken });
  if (!r.ok) toast(r.error); else if (action === 'execute') toast('任务已启动，关闭侧栏后仍会继续');
  await load();
});
async function refreshConn() {
  const tabs = await chrome.tabs.query({ url: 'http://10.198.92.173:8080/*' }).catch(() => []);
  $('#conn').classList.toggle('on', !!tabs.length); $('#connText').textContent = tabs.length ? '站点已打开' : '站点未打开';
}
let loadScheduled = false;
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !['tasks','captured','dirs','lastDirId','lastAuthAt','taskExpansion','setupExpanded','taskDirectoryHistory'].some((k) => changes[k]) || loadScheduled) return;
  loadScheduled = true;
  requestAnimationFrame(() => { loadScheduled = false; load().catch((e) => toast(e.message)); });
});
chrome.tabs.onUpdated.addListener(refreshConn); chrome.tabs.onRemoved.addListener(refreshConn);
document.addEventListener('keydown', (ev) => {
  const id = document.activeElement?.closest('.task')?.dataset.id;
  if (ev.key === 'Escape' && pendingConfirm.has(id)) { pendingConfirm.delete(id); renderTasks(); }
});
(async () => { PanelUI.init(); preset('today'); await load(); send({ type: 'capture:refresh' }); await loadLookups(); await refreshConn(); })().catch((e) => toast(e.message));
